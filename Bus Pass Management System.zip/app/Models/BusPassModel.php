<?php

namespace App\Models;

use CodeIgniter\Model;

class BusPassModel extends Model
{
    protected $table = 'bus_passes';
    protected $primaryKey = 'id';
    protected $allowedFields = ['pass_id', 'passenger_name', 'start_date', 'end_date', 'route_id', 'status'];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
}
