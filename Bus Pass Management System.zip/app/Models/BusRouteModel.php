<?php

namespace App\Models;

use CodeIgniter\Model;

class BusRouteModel extends Model
{
    protected $table = 'bus_routes';
    protected $primaryKey = 'id';
    protected $allowedFields = ['route_name', 'cost', 'created_at'];
}
