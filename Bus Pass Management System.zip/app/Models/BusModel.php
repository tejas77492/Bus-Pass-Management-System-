<?php

namespace App\Models;

use CodeIgniter\Model;

class BusModel extends Model
{
    protected $table = 'buses';
    protected $primaryKey = 'id';
    protected $allowedFields = ['bus_number', 'bus_name', 'route_id', 'capacity', 'status', 'created_at', 'updated_at'];
    protected $useTimestamps = true;
}
