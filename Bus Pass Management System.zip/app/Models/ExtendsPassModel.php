<?php

namespace App\Models;

use CodeIgniter\Model;

class ExtendsPassModel extends Model
{
    protected $table = 'extends_passes';
    protected $primaryKey = 'id';
    protected $allowedFields = ['pass_id', 'new_end_date', 'created_at', 'updated_at'];

    public function extendPass($data)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('bus_passes');

        // Transaction सुरू करा
        $db->transStart();

        // **extends_passes** मध्ये नवीन एंट्री जोडा
        $this->insert($data);

        // **bus_passes** टेबलमध्ये **end_date** अपडेट करा
        $builder->where('pass_id', $data['pass_id'])
                ->update(['end_date' => $data['new_end_date']]);

        // Transaction पूर्ण करा
        $db->transComplete();

        return $db->transStatus(); // यशस्वी झाले की नाही ते तपासा
    }
    public function updatePassEndDate($pass_id, $new_end_date)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('bus_passes');
    
        // Ensure where clause is present
        $builder->where('id', $pass_id);
        $builder->update(['end_date' => $new_end_date]);
    }
    
}
