<?php

namespace App\Models;

use CodeIgniter\Model;

class ExtendPassModel extends Model
{
    protected $table = 'extends_passes';
    protected $primaryKey = 'id';
    protected $allowedFields = ['pass_id', 'new_end_date'];
}
