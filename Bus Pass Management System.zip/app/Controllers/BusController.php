<?php

namespace App\Controllers;

use App\Models\BusModel;
use App\Models\BusRouteModel;
use CodeIgniter\Controller;

class BusController extends Controller
{
    protected $busModel;
    protected $routeModel;
    protected $helpers = ['form'];

    public function __construct()
    {
        $this->busModel = new BusModel();
        $this->routeModel = new BusRouteModel();
    }

    public function index()
    {
        $data['buses'] = $this->busModel->select('buses.*, bus_routes.route_name')
            ->join('bus_routes', 'bus_routes.id = buses.route_id')
            ->findAll();

        return view('buses/index', $data);
    }

    public function create()
    {
        $data['routes'] = $this->routeModel->findAll();
        return view('buses/create', $data);
    }

    public function store()
    {
        if ($this->validate([
            'bus_number' => 'required|is_unique[buses.bus_number]',
            'bus_name' => 'required',
            'route_id' => 'required|integer',
            'capacity' => 'required|integer',
            'status' => 'required|in_list[active,inactive]'
        ])) {
            $this->busModel->save([
                'bus_number' => $this->request->getPost('bus_number'),
                'bus_name' => $this->request->getPost('bus_name'),
                'route_id' => $this->request->getPost('route_id'),
                'capacity' => $this->request->getPost('capacity'),
                'status' => $this->request->getPost('status')
            ]);

            return redirect()->to('/manage-buses')->with('success', 'Bus added successfully.');
        }

        return redirect()->back()->withInput()->with('error', 'Validation failed!');
    }

    public function edit($id)
    {
        $data['bus'] = $this->busModel->find($id);
        $data['routes'] = $this->routeModel->findAll();
        return view('buses/edit', $data);
    }

    public function update($id)
    {
        if ($this->validate([
            'bus_number' => "required|is_unique[buses.bus_number,id,{$id}]",
            'bus_name' => 'required',
            'route_id' => 'required|integer',
            'capacity' => 'required|integer',
            'status' => 'required|in_list[active,inactive]'
        ])) {
            $this->busModel->update($id, [
                'bus_number' => $this->request->getPost('bus_number'),
                'bus_name' => $this->request->getPost('bus_name'),
                'route_id' => $this->request->getPost('route_id'),
                'capacity' => $this->request->getPost('capacity'),
                'status' => $this->request->getPost('status')
            ]);

            return redirect()->to('/manage-buses')->with('success', 'Bus updated successfully.');
        }

        return redirect()->back()->withInput()->with('error', 'Validation failed!');
    }

    public function delete($id)
    {
        $this->busModel->delete($id);
        return redirect()->to('/manage-buses')->with('success', 'Bus deleted successfully.');
    }
    public function view()
    {
        $data['buses'] = $this->busModel->select('buses.*, bus_routes.route_name')
            ->join('bus_routes', 'bus_routes.id = buses.route_id')
            ->where('buses.status', 'active') // फक्त active buses दाखवायच्या
            ->findAll();
    
        return view('buses/view', $data);
    }
    
}
