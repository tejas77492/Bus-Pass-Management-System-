<?php

namespace App\Controllers;

use App\Models\BusRouteModel;
use CodeIgniter\Controller;

class BusRouteController extends Controller
{
    public function index()
    {
        $model = new BusRouteModel();
        $data['routes'] = $model->findAll();
        return view('bus_routes/index', $data);
    }

    
    public function create()
    {
        return view('bus_routes/create'); // ✅ फॉर्म व्ह्यू लोड करतोय का?
    }

    public function store()
    {
        $model = new BusRouteModel();
        $model->insert([
            'route_name' => $this->request->getPost('route_name'),
            'cost' => $this->request->getPost('cost'),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    
        return redirect()->to('/bus-routes')->with('success', 'Bus Route Create successfully.');;
    }

    public function edit($id)
    {
        $model = new BusRouteModel();
        $data['route'] = $model->find($id);
        return view('bus_routes/edit', $data);
    }

    public function update($id)
    {
        $model = new BusRouteModel();
        $model->update($id, [
            'route_name' => $this->request->getPost('route_name'),
            'cost' => $this->request->getPost('cost'),
        ]);
        return redirect()->to('/bus-routes');
    }

    public function delete($id)
    {
        $model = new BusRouteModel();
        $model->delete($id);
        return redirect()->to('/bus-routes');
    }

    public function view()
{
    $model = new BusRouteModel();
    $data['routes'] = $model->findAll(); // सर्व Routes घेतो

    return view('bus_routes/view', $data);
}

}
