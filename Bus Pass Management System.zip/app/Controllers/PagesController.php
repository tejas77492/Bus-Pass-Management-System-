<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class PagesController extends Controller
{
    public function about()
    {
        return view('about');
    }
}
