<?php

namespace App\Controllers;

use App\Models\BusPassModel;
use CodeIgniter\Controller;

class PassengerPassController extends Controller
{
    public function myPasses()
    {
        if (!session()->has('passenger_name')) {
            return redirect()->to('/passenger/login')->with('error', 'Please login first!');
        }

        $passengerName = session()->get('passenger_name');
        $model = new BusPassModel();
        
        // फक्त लॉगिन केलेल्या युजरचे पासेस मिळवा
        $data['passes'] = $model->select('bus_passes.*, bus_routes.route_name')
                        ->join('bus_routes', 'bus_routes.id = bus_passes.route_id')
                        ->findAll();


        return view('pass/view', $data);
    }
    public function extend($pass_id)
    {
        $model = new BusPassModel();
        $pass = $model->select('bus_passes.*, bus_routes.route_name')
                      ->join('bus_routes', 'bus_routes.id = bus_passes.route_id')
                      ->where('bus_passes.pass_id', $pass_id)
                      ->first();

        return view('passenger/extend_pass', ['pass' => $pass]);
    }

    public function processExtend()
    {
        $pass_id = $this->request->getPost('pass_id');
        $new_end_date = $this->request->getPost('new_end_date');

        $extendModel = new ExtendPassModel();
        $extendModel->save([
            'pass_id' => $pass_id,
            'new_end_date' => $new_end_date,
        ]);

        $busPassModel = new BusPassModel();
        $busPassModel->update($pass_id, ['end_date' => $new_end_date]);

        return redirect()->to('/passenger/passes')->with('success', 'Pass Extended Successfully');
    }
}

