<?php

namespace App\Controllers;

use App\Models\ExtendsPassModel;
use App\Models\BusPassModel;
use CodeIgniter\Controller;

class ExtendsPasses extends Controller
{
    public function index()
    {
        $model = new ExtendsPassModel();
        $data['extends_passes'] = $model->findAll();

        return view('extends_passes/index', $data);
    }

    public function create($pass_id)
    {
        $model = new BusPassModel();
        $pass = $model->where('pass_id', $pass_id)->first();
    
        if (!$pass) {
            return redirect()->to('/passenger')->with('error', 'Pass not found');
        }
    
        return view('extends_passes/create', ['extend_pass' => $pass]); // ✅ Variable नाव बरोबर द्या!
    }
    

    public function store()
    {
        $pass_id = $this->request->getPost('pass_id');
        $new_end_date = $this->request->getPost('new_end_date');
    
        $model = new BusPassModel();
        $model->update($pass_id, ['end_date' => $new_end_date]);
    
        return redirect()->to('/passenger')->with('success', 'Pass extended successfully');
    }

   
    public function update($id)
    {
        if (!$id) {
            return redirect()->to('/extends-passes')->with('error', 'Invalid request!');
        }
    
        log_message('debug', 'Updating pass with ID: ' . $id);
        
        $model = new ExtendsPassModel();
        $busPassModel = new BusPassModel();
    
        $new_end_date = $this->request->getPost('new_end_date');
        $pass_id = $this->request->getPost('pass_id');
    
        if (!$new_end_date || !$pass_id) {
            return redirect()->to('/extends-passes')->with('error', 'Invalid data provided!');
        }
    
        if (!$model->find($id)) {
            return redirect()->to('/extends-passes')->with('error', 'Extend pass not found!');
        }
    
        $model->update($id, ['new_end_date' => $new_end_date]);
    
        if ($busPassModel->where('pass_id', $pass_id)->first()) {
            $busPassModel->where('pass_id', $pass_id)->set(['end_date' => $new_end_date])->update();
        } else {
            return redirect()->to('/extends-passes')->with('error', 'Bus pass not found!');
        }
    
        return redirect()->to('/extends-passes')->with('success', 'Pass extended successfully and updated in Manage Pass!');
    }
    

    public function delete($id)
    {
        $model = new ExtendsPassModel();
        $model->delete($id);

        return redirect()->to('/extends-passes')->with('success', 'Extension deleted successfully');
    }

    public function extendPass()
    {
        $model = new ExtendsPassModel();

        $data = [
            'pass_id'      => $this->request->getPost('pass_id'),
            'new_end_date' => $this->request->getPost('new_end_date'),
            'created_at'   => date('Y-m-d H:i:s'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ];

        if ($model->extendPass($data)) {
            return redirect()->to('/bus-passes')->with('success', 'Pass extended successfully!');
        } else {
            return redirect()->back()->with('error', 'Failed to extend pass.');
        }
    }

    public function edit($id)
    {
        $model = new ExtendsPassModel();

        // Database मधून extend_pass ID ने डेटा मिळवायचा
        $extend_pass = $model->find($id);

        // जर डेटा सापडला नाही तर 404 Error द्या
        if (!$extend_pass) {
            return redirect()->to('/extends-passes')->with('error', 'Extend pass not found');
        }

        // View ला डेटा पाठवा
        return view('extends_passes/edit', ['extend_pass' => $extend_pass]);
    }
}
