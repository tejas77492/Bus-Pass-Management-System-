<?php
namespace App\Controllers;

use App\Models\BusPassModel;
use CodeIgniter\Controller;

class PassengerAuthController extends Controller
{
    public function login()
    {
        return view('pass/login');
    }

    public function authenticate()
    {
        $passengerName = $this->request->getPost('passenger_name');

        $model = new BusPassModel();
        $passengerPass = $model->select('bus_passes.*, bus_routes.route_name')
                               ->join('bus_routes', 'bus_routes.id = bus_passes.route_id')
                               ->where('bus_passes.passenger_name', $passengerName)
                               ->first();

        if ($passengerPass) {
            session()->set('passenger_name', $passengerName);
            session()->set('passenger_pass', $passengerPass);
            return redirect()->to('/passenger/passes');
        } else {
            return redirect()->to('/passenger/login')->with('error', 'Invalid Passenger Name');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/passenger/login');
    }
}
