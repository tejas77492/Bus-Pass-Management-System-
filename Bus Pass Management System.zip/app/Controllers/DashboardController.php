<?php
namespace App\Controllers;

use CodeIgniter\Controller;

class DashboardController extends Controller
{
    public function index()
    {
        return view('dashboard'); // Ensure dashboard.php exists in app/Views/
    }
}
