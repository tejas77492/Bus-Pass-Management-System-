<?php

namespace App\Controllers;

use App\Models\BusPassModel;
use App\Models\BusRouteModel;
use CodeIgniter\Controller;

class BusPassController extends Controller
{
    public function index()
{
    $model = new BusPassModel();
    
    // Route सोबत Pass Data Fetch करणे
    $data['passes'] = $model->select('bus_passes.*, bus_routes.route_name, bus_routes.cost')
                            ->join('bus_routes', 'bus_routes.id = bus_passes.route_id')
                            ->findAll();

    return view('bus_passes/index', $data);
}


    // public function create()
    // {
    //     $routeModel = new BusRouteModel();
    //     $data['routes'] = $routeModel->findAll();
    //     return view('bus_passes/create', $data);
    // }
    public function create()
    {
        $busRouteModel = new BusRouteModel();
        $data['routes'] = $busRouteModel->findAll();
        return view('bus_passes/create', $data);
    }

    public function store()
    {
        $busPassModel = new BusPassModel();

        $passId = 'PASS-' . strtoupper(substr(md5(uniqid()), 0, 6)); // Random Pass ID

        $data = [
            'pass_id' => $passId,
            'passenger_name' => $this->request->getPost('passenger_name'),
            'start_date' => $this->request->getPost('start_date'),
            'end_date' => $this->request->getPost('end_date'),
            'route_id' => $this->request->getPost('route_id'),
        ];

        $busPassModel->insert($data);
        return redirect()->to('/bus-routes/view')->with('success', 'Bus pass created successfully!');
    }
    public function edit($id)
    {
        $model = new BusPassModel();
        $busPass = $model->find($id);

        if (!$busPass) {
            return redirect()->to('/passenger/pass')->with('error', 'Bus pass not found!');
        }

        return view('bus_passes/edit', ['busPass' => $busPass]);
    }

    public function update($id)
{
    $model = new BusPassModel();

    // **Check if ID exists**
    $pass = $model->find($id);
    if (!$pass) {
        return redirect()->back()->with('error', 'Invalid Pass ID');
    }

    $data = [
        'passenger_name' => $this->request->getPost('passenger_name'),
        'start_date'     => $this->request->getPost('start_date'),
        'end_date'       => $this->request->getPost('end_date'),
        'route_id'       => $this->request->getPost('route_id'),
        'updated_at'     => date('Y-m-d H:i:s'),
    ];

    if ($model->update($id, $data)) {
        return redirect()->to('/passenger/passes')->with('success', 'Bus pass updated successfully!');
    } else {
        return redirect()->back()->with('error', 'Failed to update bus pass.');
    }
}

    

    public function delete($id)
    {
        $model = new BusPassModel();
        $model->delete($id);
        return redirect()->to('/bus-passes');
    }
    public function view()
    {
        $model = new BusPassModel();
        
        // सर्व बस पासेस आणा
        $data['passes'] = $model->select('bus_passes.*, bus_routes.route_name, bus_routes.cost')
                                ->join('bus_routes', 'bus_routes.id = bus_passes.route_id')
                                ->findAll();
    
        return view('bus_passes/view', $data);
    }
    
 

}
