<?php
namespace App\Controllers;

use App\Models\AdminModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    public function login()
    {
        return view('auth/login'); // Load login view
    }

    public function processLogin()
    {
        $session = session();
        $model = new AdminModel();
        
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $admin = $model->where('username', $username)->first();

        if ($admin && password_verify($password, $admin['password'])) {
            $session->set(['isLoggedIn' => true, 'admin_id' => $admin['id']]);
            return redirect()->to('/dashboard'); // Redirect to dashboard
        } else {
            return redirect()->to('/login')->with('error', 'Invalid login credentials');
        }
    }

    public function register()
    {
        return view('auth/register'); // Load registration view
    }

    public function processRegister()
    {
        $model = new AdminModel();
        
        $data = [
            'username'   => $this->request->getPost('username'),
            'password'   => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s') // Manually setting created_at
        ];

        $model->insert($data);
        return redirect()->to('/login')->with('success', 'Registration successful! You can now log in.');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
