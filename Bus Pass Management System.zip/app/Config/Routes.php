<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'HomeController::index');


// Authentication Routes
$routes->get('/login', 'AuthController::login'); 
$routes->post('/login', 'AuthController::processLogin');
$routes->get('/logout', 'AuthController::logout');
$routes->get('/dashboard', 'DashboardController::index', ['filter' => 'auth']);

$routes->get('/register', 'AuthController::register');
$routes->post('/register', 'AuthController::processRegister');

// Bus Pass 
// $routes->group('manage-passes', ['filter' => 'auth'], function ($routes) {
//     $routes->get('/', 'BusPassController::index');
//     $routes->get('create', 'BusPassController::create');
//     $routes->post('store', 'BusPassController::store');
//     $routes->get('edit/(:num)', 'BusPassController::edit/$1');
//     $routes->post('update/(:num)', 'BusPassController::update/$1');
//     $routes->get('delete/(:num)', 'BusPassController::delete/$1');
// });
$routes->get('bus-passes', 'BusPassController::index');
$routes->get('bus-passes/create', 'BusPassController::create');
$routes->post('bus-passes/store', 'BusPassController::store');
$routes->get('bus-passes/edit/(:num)', 'BusPassController::edit/$1');
$routes->post('bus-passes/update/(:num)', 'BusPassController::update/$1');
$routes->get('bus-passes/delete/(:num)', 'BusPassController::delete/$1');




// Bus Route Routes
$routes->get('/bus-routes', 'BusRouteController::index');
$routes->get('/bus-routes/create', 'BusRouteController::create');
$routes->post('/bus-routes/store', 'BusRouteController::store');
$routes->get('/bus-routes/edit/(:num)', 'BusRouteController::edit/$1');
$routes->post('/bus-routes/update/(:num)', 'BusRouteController::update/$1');
$routes->get('/bus-routes/delete/(:num)', 'BusRouteController::delete/$1');


// Bus Routes
$routes->group('manage-buses', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', 'BusController::index');
    $routes->get('create', 'BusController::create'); 
    $routes->post('store', 'BusController::store');
    $routes->get('edit/(:num)', 'BusController::edit/$1'); // ✅ Fixed route
    $routes->post('update/(:num)', 'BusController::update/$1');
    $routes->get('delete/(:num)', 'BusController::delete/$1');
});

//Extends Pass
$routes->post('extends-passes', 'ExtendsPasses::extendPass');
$routes->get('/extends-passes', 'ExtendsPasses::index');
$routes->get('/extends-passes/create', 'ExtendsPasses::create');
$routes->post('/extends-passes/store', 'ExtendsPasses::store');
$routes->get('/extends-passes/edit/(:num)', 'ExtendsPasses::edit/$1');
$routes->post('/extends-passes/update/(:num)', 'ExtendsPasses::update/$1');
$routes->get('/extends-passes/delete/(:num)', 'ExtendsPasses::delete/$1');

$routes->get('/users', 'UserController::index');
$routes->get('/users/create', 'UserController::create');
$routes->post('/users/store', 'UserController::store');
$routes->get('/users/edit/(:num)', 'UserController::edit/$1');
$routes->post('/users/update/(:num)', 'UserController::update/$1');
$routes->get('/users/delete/(:num)', 'UserController::delete/$1');

$routes->get('/user/login', 'UserController::login');
$routes->post('/user/authenticate', 'UserController::authenticate');
$routes->get('/logout', 'UserController::logout');


$routes->get('bus-routes/view', 'BusRouteController::view');

$routes->get('/user/passes', 'BusPassController::userPasses');
$routes->get('/bus-passes/view', 'BusPassController::view');


$routes->get('/passenger/login', 'PassengerAuthController::login');
$routes->post('/passenger/authenticate', 'PassengerAuthController::authenticate');
$routes->get('/passenger/logout', 'PassengerAuthController::logout');
$routes->get('/passenger/passes', 'PassengerPassController::myPasses'); // फक्त लॉगिन केलेल्या युजरचे पासेस


$routes->get('/passenger/extend/(:any)', 'PassengerPassController::extend/$1');
$routes->post('/passenger/extend', 'PassengerPassController::processExtend');



$routes->get('/about', 'PagesController::about');

$routes->get('buses/view', 'BusController::view');

$routes->get('extends-passes/create/(:segment)', 'ExtendsPasses::create/$1');
$routes->post('extends-passes/update', 'ExtendsPasses::update');

$routes->post('extends_pass/update/(:num)', 'ExtendsPasses::update/$1');


$routes->get('/bus-passes/edit/(:num)', 'BusPassController::edit/$1');
$routes->post('/bus-passes/update/(:num)', 'BusPassController::update/$1');


$routes->get('/about', 'PagesController::about');
