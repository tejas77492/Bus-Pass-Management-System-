<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Buses</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">


</head>
<body>

    <div class="container mt-5">
        <h2 class="mb-4 text-primary fw-bold text-center">Available Buses</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Bus Number</th>
                        <th>Bus Name</th>
                        <th>Route</th>
                        <th>Capacity</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($buses)): ?>
                        <?php foreach ($buses as $bus): ?>
                            <tr>
                                <td><?= esc($bus['bus_number']) ?></td>
                                <td><?= esc($bus['bus_name']) ?></td>
                                <td><?= esc($bus['route_name']) ?></td>
                                <td><?= esc($bus['capacity']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $bus['status'] === 'active' ? 'success' : 'danger' ?>">
                                        <?= ucfirst($bus['status']) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">No buses available.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
