<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Bus</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #343a40;
            color: white;
            position: fixed;
        }
        .sidebar .nav-link {
            color: white;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #d9534f;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Bus Station</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar p-3">
    <h4 class="text-center">Admin Panel</h4>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="/dashboard" class="nav-link"><i class="bi bi-house-door"></i> Dashboard</a></li>
        <li class="nav-item"><a href="/bus-passes" class="nav-link"><i class="bi bi-card-list"></i> Bus Passes</a></li>
        <li class="nav-item"><a href="/bus-routes" class="nav-link"><i class="bi bi-map"></i> Bus Routes</a></li>
        <li class="nav-item"><a href="/manage-buses" class="nav-link"><i class="bi bi-bus-front"></i> Buses</a></li>
        <li class="nav-item"><a href="/" class="nav-link text-danger"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="container mt-4">
        <h2 class="mb-4">Add New Bus</h2>

        <?php if (session()->getFlashdata('error')) : ?>
            <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <div class="card shadow-lg p-4">
            <form action="<?= base_url('manage-buses/store') ?>" method="post">
                <div class="mb-3">
                    <label class="form-label">Bus Number</label>
                    <input type="text" name="bus_number" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Bus Name</label>
                    <input type="text" name="bus_name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Route</label>
                    <select name="route_id" class="form-control" required>
                        <?php foreach ($routes as $route) : ?>
                            <option value="<?= $route['id'] ?>"><?= $route['route_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Capacity</label>
                    <input type="number" name="capacity" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success w-100">Add Bus</button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
