<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Bus Pass</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar Design */
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #343a40;
            color: white;
            padding-top: 20px;
            position: fixed;
            left: 0;
            top: 0;
        }
        .sidebar h3 {
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            font-size: 18px;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background: #495057;
            border-left: 4px solid #007bff;
        }
        .content {
            margin-left: 260px;
            padding: 30px;
            width: 100%;
        }
        /* Navbar Design */
        .navbar {
            background: #ffffff;
            padding: 15px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }
        /* Card Design */
        .card {
            border-radius: 10px;
            overflow: hidden;
        }
        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 22px;
            font-weight: bold;
            text-align: center;
        }
        /* Button Design */
        .btn-custom {
            background-color: #28a745;
            color: white;
            font-size: 18px;
            padding: 10px;
            border-radius: 5px;
            transition: 0.3s;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>Dashboard</h3>
    <a href="/bus-routes/view">🚌 View Routes</a>
    <a href="/bus-passes/create">📝 Create Pass</a>
    <a href="/home">🚪 Logout</a>
</div>

<!-- Content -->
<div class="content">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold text-primary" href="#">Bus Pass Management</a>
        </div>
    </nav>

    <!-- Form Section -->
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-lg">
                    <div class="card-header">
                        Add Bus Pass
                    </div>
                    <div class="card-body">
                        <form action="<?= base_url('/bus-passes/store') ?>" method="post">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Pass ID:</label>
                                <input type="text" name="pass_id" class="form-control" 
                                    value="<?= 'PASS-' . strtoupper(bin2hex(random_bytes(3))) ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Passenger Name:</label>
                                <input type="text" name="passenger_name" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Route:</label>
                                <select name="route_id" id="route_id" class="form-control" required>
                                    <option value="">Select Route</option>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?= $route['id'] ?>" data-cost="<?= $route['cost'] ?>">
                                            <?= $route['route_name'] ?> - ₹<?= number_format($route['cost'], 2) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Cost:</label>
                                <input type="text" id="cost" name="cost" class="form-control" readonly>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Start Date:</label>
                                        <input type="date" name="start_date" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">End Date:</label>
                                        <input type="date" name="end_date" class="form-control" required>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-custom w-100">Save Bus Pass</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById('route_id').addEventListener('change', function() {
            let cost = this.options[this.selectedIndex].getAttribute('data-cost');
            document.getElementById('cost').value = cost;
        });
    });
</script>

</body>
</html>
