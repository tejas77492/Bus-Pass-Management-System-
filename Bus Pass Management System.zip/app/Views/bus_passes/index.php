<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bus Passes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #343a40;
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 60px;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }
        .sidebar .nav-link {
            color: white;
            padding: 10px;
            display: block;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
        }
        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #d9534f;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Bus Station</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <h4 class="text-center mt-3">Admin Panel</h4>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="/dashboard" class="nav-link"><i class="fas fa-home"></i> Dashboard</a></li>
        <li class="nav-item"><a href="/bus-passes" class="nav-link"><i class="bi bi-card-list"></i> Bus Passes</a></li>
        <li class="nav-item"><a href="/bus-routes" class="nav-link"><i class="bi bi-map"></i> Bus Routes</a></li>
        <li class="nav-item"><a href="/manage-buses" class="nav-link"><i class="bi bi-bus-front"></i> Buses</a></li>
        <li class="nav-item"><a href="/" class="nav-link text-danger"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="container mt-4">
        <h2 class="mb-4 text-primary fw-bold text-center">Manage Bus Passes</h2>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Total Passes: <?= count($passes) ?></span>
        </div>

        <div class="card shadow-lg p-4">
            <?php if (empty($passes)): ?>
                <div class="alert alert-warning text-center fw-bold">
                    <i class="bi bi-exclamation-triangle-fill"></i> No bus passes found.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered align-middle">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>Pass ID</th>
                                <th>Passenger Name</th>
                                <th>Route</th>
                                <th>Cost</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php foreach ($passes as $pass): ?>
                                <tr>
                                    <td class="fw-bold"><?= $pass['pass_id']; ?></td>
                                    <td><?= $pass['passenger_name']; ?></td>
                                    <td class="text-primary fw-bold"><?= $pass['route_name']; ?></td>
                                    <td class="text-success fw-bold">₹<?= number_format($pass['cost'], 2); ?></td>
                                    <td><?= date('d-M-Y', strtotime($pass['start_date'])); ?></td>
                                    <td><?= date('d-M-Y', strtotime($pass['end_date'])); ?></td>
                                    <td>
                                        <a href="<?= base_url('/bus-passes/delete/' . $pass['id']) ?>" 
                                           class="btn btn-danger btn-sm" 
                                           onclick="return confirm('Are you sure?')">
                                            <i class="bi bi-trash"></i> Delete
                                        </a>
                                        <!-- <a href="<?= base_url('/bus-passes/edit/' . $pass['id']) ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </a> -->
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>





