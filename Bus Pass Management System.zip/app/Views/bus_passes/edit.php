<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Bus Pass</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Extends Bus Pass</h2>

        <?php if (session()->has('error')) : ?>
            <div class="alert alert-danger"><?= session('error') ?></div>
        <?php endif; ?>

        <form action="<?= base_url('bus-passes/update/' . $busPass['id']) ?>" method="post">
            <div class="mb-3">
                <label class="form-label">Passenger Name</label>
                <input type="text" class="form-control" name="passenger_name" value="<?= esc($busPass['passenger_name']); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Start Date</label>
                <input type="date" class="form-control" name="start_date" value="<?= esc($busPass['start_date']); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">End Date</label>
                <input type="date" class="form-control" name="end_date" value="<?= esc($busPass['end_date']); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Route ID</label>
                <input type="number" class="form-control" name="route_id" value="<?= esc($busPass['route_id']); ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Update Pass</button>
            <a href="<?= base_url('passenger/pass') ?>" class="btn btn-secondary">Back</a>
        </form>
    </div>
</body>
</html>
