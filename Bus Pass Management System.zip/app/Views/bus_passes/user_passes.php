<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bus Passes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2 class="text-center">My Bus Passes</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Pass ID</th>
                <th>Passenger Name</th>
                <th>Route</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Cost</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($passes as $pass): ?>
                <tr>
                    <td><?= $pass['pass_id'] ?></td>
                    <td><?= $pass['passenger_name'] ?></td>
                    <td><?= $pass['route_name'] ?></td>
                    <td><?= $pass['start_date'] ?></td>
                    <td><?= $pass['end_date'] ?></td>
                    <td>₹<?= number_format($pass['cost'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
