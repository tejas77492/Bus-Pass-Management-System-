<h2>Edit User</h2>
<form action="/users/update/<?= $user['id']; ?>" method="post">
    <label>Name:</label>
    <input type="text" name="name" value="<?= $user['name']; ?>" required><br>
    <label>Email:</label>
    <input type="email" name="email" value="<?= $user['email']; ?>" required><br>
    <label>New Password (optional):</label>
    <input type="password" name="password"><br>
    <button type="submit">Update</button>
</form>
