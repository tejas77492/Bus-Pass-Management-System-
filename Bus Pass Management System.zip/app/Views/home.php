<?php include APPPATH . 'Views/layouts/header.php'; ?>

<!-- Hero Section -->
<div class="container-fluid hero-section text-center text-white d-flex align-items-center justify-content-center" style="background: url('/assets/images/bus-bg.jpg') no-repeat center center/cover; height: 70vh;">
    <div>
        <h1 class="display-4 fw-bold">Welcome to Bus Pass Management System</h1>
        <p class="lead">Apply for your bus pass online with ease and convenience</p>
        <a href="/login" class="btn btn-primary btn-lg">Admin</a><br> <br>
        <a href="/users/create" class="btn btn-primary btn-lg">users</a>
    </div>
</div>

<!-- Features Section -->
<div class="container py-5">
    <div class="row text-center">
        <div class="col-md-4">
            <i class="bi bi-card-checklist text-primary" style="font-size: 3rem;"></i>
            <h4 class="mt-3">Easy Pass Management</h4>
            <p>Apply, renew, and track your bus pass online.</p>
        </div>
        <div class="col-md-4">
            <i class="bi bi-lock text-success" style="font-size: 3rem;"></i>
            <h4 class="mt-3">Secure System</h4>
            <p>Fully secure and encrypted database to protect your data.</p>
        </div>
        <div class="col-md-4">
            <i class="bi bi-cloud-download text-warning" style="font-size: 3rem;"></i>
            <h4 class="mt-3">Online Application</h4>
            <p>Apply for a pass anytime, anywhere.</p>
        </div>
    </div>
</div>

<!-- How It Works Section -->
<div class="container py-5">
    <h2 class="text-center mb-4">How It Works</h2>
    <div class="row text-center">
        <div class="col-md-3">
            <div class="card p-3 shadow">
                <h5>1. Register</h5>
                <p>Sign up and create your account.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 shadow">
                <h5>2. Apply</h5>
                <p>Submit your bus pass application.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 shadow">
                <h5>3. Get Approved</h5>
                <p>Admin verifies and approves your application.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3 shadow">
                <h5>4. Download Pass</h5>
                <p>Get your digital bus pass instantly.</p>
            </div>
        </div>
    </div>
</div>

<?php include APPPATH . 'Views/layouts/footer.php'; ?>
