</div> <!-- Closing container-fluid -->
</div> <!-- Closing d-flex -->

<footer class="bg-dark text-white text-center p-3 mt-4">
    © 2025 Bus Pass Management System. All rights reserved.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
