<div id="sidebar" class="bg-light border-end p-3" style="width: 250px; min-height: 100vh;">
    <!-- <h4 class="text-dark">Menu</h4> -->
    <ul class="nav flex-column">
        <li class="nav-item"><a href="/dashboard" class="nav-link">Dashboard</a></li>
        <li class="nav-item"><a href="/bus-passes" class="nav-link">Manage Passes</a></li>
        <li class="nav-item"><a href="/bus-routes" class="nav-link">Manage Routes</a></li>
        <li class="nav-item"><a href="/" class="nav-link text-danger">Logout</a></li>
    </ul>
</div>
<div class="container-fluid p-4" style="flex-grow: 1;">
