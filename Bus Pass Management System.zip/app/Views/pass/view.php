<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passenger Bus Pass</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Your Bus Pass</h2>
        
        <a href="/passenger/logout" class="btn btn-danger mb-3">Back</a>

        <?php if (session()->has('passenger_pass')) : 
            $pass = session()->get('passenger_pass'); 
        ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Pass ID</th>
                        <th>Passenger Name</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Route Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= esc($pass['pass_id']); ?></td>
                        <td><?= esc($pass['passenger_name']); ?></td>
                        <td><?= esc($pass['start_date']); ?></td>
                        <td><?= esc($pass['end_date']); ?></td>
                        <td><?= esc($pass['route_name']); ?></td>
                        <td>
                            <a href="/bus-passes/edit/<?= esc($pass['id']); ?>" class="btn btn-primary btn-sm">Extend Pass</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php else : ?>
            <div class="alert alert-warning">No Pass Found</div>
        <?php endif; ?>
    </div>
</body>
</html>
