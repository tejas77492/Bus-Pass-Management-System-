<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Extend Bus Pass</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Extend Bus Pass</h2>
        
        <form action="/passenger/extend" method="post">
            <input type="hidden" name="pass_id" value="<?= $pass['pass_id']; ?>">

            <div class="mb-3">
                <label class="form-label">Current End Date:</label>
                <input type="text" class="form-control" value="<?= $pass['end_date']; ?>" disabled>
            </div>

            <div class="mb-3">
                <label class="form-label">New End Date:</label>
                <input type="date" name="new_end_date" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Extend Pass</button>
        </form>
    </div>
</body>
</html>
