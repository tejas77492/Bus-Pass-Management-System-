<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bus Routes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #343a40;
            color: white;
            position: fixed;
        }
        .sidebar .nav-link {
            color: white;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #d9534f;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Bus Station</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar p-3">
    <h4 class="text-center">Admin Panel</h4>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="/dashboard" class="nav-link"><i class="bi bi-house-door"></i>Dashboard</a></li>
        <li class="nav-item"><a href="/bus-passes" class="nav-link"><i class="bi bi-card-list"></i> Bus Passes</a></li>
        <li class="nav-item"><a href="/bus-routes" class="nav-link"><i class="bi bi-map"></i> Bus Routes</a></li>
        <li class="nav-item"><a href="/manage-buses" class="nav-link"><i class="bi bi-bus-front"></i> Buses</a></li>
        <li class="nav-item"><a href="/" class="nav-link text-danger"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <h2 class="mb-4 text-primary fw-bold text-center">Manage Bus Routes</h2>

    <!-- Flash Message -->
    <?php if (session()->getFlashdata('success')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill"></i> <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-muted">Total Routes: <?= count($routes) ?></span>
        <a href="<?= base_url('/bus-routes/create') ?>" class="btn btn-success">
            <i class="bi bi-plus-circle"></i> Add New Route
        </a>
    </div>

    <div class="card shadow-lg p-4">
        <?php if (empty($routes)): ?>
            <div class="alert alert-warning text-center fw-bold">
                <i class="bi bi-exclamation-triangle-fill"></i> No routes found.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>ID</th>
                            <th>Route Name</th>
                            <th>Cost</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php foreach ($routes as $route): ?>
                            <tr>
                                <td class="fw-bold"><?= $route['id'] ?></td>
                                <td class="text-primary fw-bold"><?= $route['route_name'] ?></td>
                                <td class="text-success fw-bold">₹<?= number_format($route['cost'], 2) ?></td>
                                <td>
                                    <a href="<?= base_url('/bus-routes/edit/' . $route['id']) ?>" class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil"></i> Edit
                                    </a>
                                    <a href="<?= base_url('/bus-routes/delete/' . $route['id']) ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Are you sure?')">
                                        <i class="bi bi-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
