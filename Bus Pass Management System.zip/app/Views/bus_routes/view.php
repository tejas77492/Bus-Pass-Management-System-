<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus User Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f4f6f9;
            display: flex;
        }
        .navbar {
            background: #d9534f;
        }
        .navbar-brand, .nav-link {
            color: white !important;
        }
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
            color: white;
        }
        .sidebar a {
            padding: 10px;
            text-decoration: none;
            font-size: 18px;
            display: block;
            color: white;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background-color: #575d63;
        }
       
        .content {
            margin-left: 260px;
            padding: 20px;
            width: 100%;
        }
        .navbar {
            background: #ffffff;
            padding: 15px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 20px;
            font-weight: bold;
        }
        th {
            background: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }
        td {
            padding: 10px;
            text-align: center;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3 class="text-center">Dashboard</h3>
    <a href="/bus-routes/view">View Routes</a>
    <a href="/passenger/login"> View Bass</a>
    <a href="/buses/view"> View Buses</a>
    <a href="/about"> About us</a>

    <a href="/">Logout</a>
</div>

<!-- Content -->
<div class="content">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="#">User Dashboard </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
          
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header text-center">
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus User Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> 
    <style>
        body {
            background-color: #f4f6f9;
        }
        .navbar {
            background: #d9534f;
            color: white;
        }
        .navbar-brand, .nav-link {
            color: white !important;
        }
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
            color: white;
        }
        .sidebar a {
            padding: 10px;
            text-decoration: none;
            font-size: 18px;
            display: block;
            color: white;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background-color: #575d63;
        }
        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 20px;
            font-weight: bold;
        }
        th {
            background: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }
        td {
            padding: 10px;
            text-align: center;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f8f9fa;
        }
        .dashboard-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            border-radius: 10px;
            overflow: hidden;
            text-align: center;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
        .dashboard-card i {
            font-size: 3rem;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">Bus Station</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav"></div>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
<h3 class="text-center">Dashboard</h3>
 
<a href="/bus-routes/view">View Routes</a>
    <a href="/passenger/login"> View Bass</a>
    <a href="/buses/view"> View Buses</a>
    <a href="/about"> About us</a>
    <a href="/"><i class="fas fa-home"></i> Logout</a>
</div>

<!-- Cards Section (Top) -->
<div class="container mt-4">
    <div class="row">
        <!-- View Routes -->
        <div class="col-md-3">
            <div class="card dashboard-card shadow-lg p-3">
                <i class="fas fa-map text-primary"></i>
                <h5 class="fw-bold">Apply For Pass</h5>
                <p class="text-muted">Check available bus routes</p>
                <a href="/bus-passes/create" class="btn btn-primary">Create Now</a>
            </div>
        </div>

        <!-- View Passes -->
        <div class="col-md-3">
            <div class="card dashboard-card shadow-lg p-3">
                <i class="fas fa-ticket-alt text-success"></i>
                <h5 class="fw-bold">View Pass</h5>
                <p class="text-muted">Manage your bus passes</p>
                <a href="/passenger/login" class="btn btn-success">Go to Passes</a>
            </div>
        </div>

        <!-- View Buses -->
        <div class="col-md-3">
            <div class="card dashboard-card shadow-lg p-3">
                <i class="fas fa-bus text-warning"></i>
                <h5 class="fw-bold">View Buses</h5>
                <p class="text-muted">See all available buses</p>
                <a href="/buses/view" class="btn btn-warning">Check Buses</a>
            </div>
        </div>

        <!-- About Us -->
        <div class="col-md-3">
            <div class="card dashboard-card shadow-lg p-3">
                <i class="fas fa-info-circle text-info"></i>
                <h5 class="fw-bold">About Us</h5>
                <p class="text-muted">Learn more about us</p>
                <a href="/about" class="btn btn-info">Know More</a>
            </div>
        </div>
    </div>
</div>

<!-- Bus Routes Table (Below Cards) -->
<div class="container mt-4">
    <div class="card">
        <div class="card-header text-center">
            <h2>🚌 Bus Routes</h2>
        </div>
        <div class="card-body">
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success'); ?>
                </div>
            <?php endif; ?>

            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Route Name</th>
                        <th>Cost</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($routes)) : ?>
                        <?php foreach ($routes as $route) : ?>
                            <tr>
                                <td><?= esc($route['id']) ?></td>
                                <td><?= esc($route['route_name']) ?></td>
                                <td><b>₹<?= esc($route['cost']) ?> </b></td>
                                <td><?= esc($route['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">No routes found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>


</body>
</html>
