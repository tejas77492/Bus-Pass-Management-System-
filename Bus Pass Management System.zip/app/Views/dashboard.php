<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #343a40; /* Updated Sidebar Color */
            color: white;
        }
        .sidebar .nav-link {
            color: white;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #d9534f;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Bus Station</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Sidebar and Content -->
<div class="d-flex">
    <div class="sidebar p-3">
        <h4 class="text-center">Admin Panel</h4>
        <ul class="nav flex-column">
            <li class="nav-item"><a href="/dashboard" class="nav-link"><i class="fas fa-home"></i> Dashboard</a></li>
            <li class="nav-item"><a href="/bus-passes" class="nav-link"><i class="bi bi-card-list"></i> Bus Passes</a></li>
            <li class="nav-item"><a href="/bus-routes" class="nav-link"><i class="bi bi-map"></i> Bus Routes</a></li>
            <li class="nav-item"><a href="/manage-buses" class="nav-link"><i class="bi bi-bus-front"></i> Buses</a></li>
            <li class="nav-item"><a href="/" class="nav-link text-danger"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content p-4" style="flex-grow: 1;">
        <h2 class="mb-4 text-primary fw-bold">Admin Dashboard</h2>
        
        <div class="row">
            <div class="col-md-3">
                <div class="card shadow-lg text-center p-3">
                    <i class="bi bi-card-list text-primary" style="font-size: 3rem;"></i>
                    <h5 class="mt-3 fw-bold">Manage Bus Passes</h5>
                    <p class="text-muted">View, create, and update bus passes</p>
                    <a href="/bus-passes" class="btn btn-primary">
                        <i class="bi bi-arrow-right-circle"></i> Go to Passes
                    </a>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow-lg text-center p-3">
                    <i class="bi bi-map text-success" style="font-size: 3rem;"></i>
                    <h5 class="mt-3 fw-bold">Manage Routes</h5>
                    <p class="text-muted">Add or modify bus routes</p>
                    <a href="/bus-routes" class="btn btn-success">
                        <i class="bi bi-arrow-right-circle"></i> Go to Routes
                    </a>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow-lg text-center p-3">
                    <i class="bi bi-bus-front text-warning" style="font-size: 3rem;"></i>
                    <h5 class="mt-3 fw-bold">Manage Buses</h5>
                    <p class="text-muted">Add, edit, or remove buses</p>
                    <a href="/manage-buses" class="btn btn-warning">
                        <i class="bi bi-arrow-right-circle"></i> Go to Buses
                    </a>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow-lg text-center p-3">
                    <i class="bi bi-box-arrow-right text-danger" style="font-size: 3rem;"></i>
                    <h5 class="mt-3 fw-bold">Logout</h5>
                    <p class="text-muted">Exit the admin panel securely</p>
                    <a href="/" class="btn btn-danger">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
