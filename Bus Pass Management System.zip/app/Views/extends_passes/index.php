<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container mt-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <h3 class="text-center">Extended Passes</h3>
        </div>
        <div class="card-body">
            <a href="/extends-passes/create" class="btn btn-success mb-3">Extend New Pass</a>

            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Pass ID</th>
                        <th>New End Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($extends_passes as $pass) : ?>
                        <tr>
                            <td><?= $pass['id'] ?></td>
                            <td><?= $pass['pass_id'] ?></td>
                            <td><?= $pass['new_end_date'] ?></td>
                            <td>
                                <a href="/extends-passes/edit/<?= $pass['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="/extends-passes/delete/<?= $pass['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
