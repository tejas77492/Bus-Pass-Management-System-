<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Extend Bus Pass</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Extend Your Bus Pass</h2>
        
        <form action="<?= base_url('extends_pass/update/' . $extend_pass['id']) ?>" method="post">
    <input type="hidden" name="pass_id" value="<?= $extend_pass['pass_id']; ?>">
    <label>New End Date:</label>
    <input type="date" name="new_end_date" required>
    <button type="submit">Extend</button>
</form>

    </div>
</body>
</html>
