<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<h2 class="mb-4">Edit Extended Pass</h2>

<<form action="<?= base_url('extends-passes/update/' . $extend_pass['id']) ?>" method="post">
    <label>New End Date:</label>
    <input type="date" name="new_end_date" value="<?= $extend_pass['new_end_date'] ?>" required>
    
    <button type="submit">Update</button>
</form>


<?= $this->endSection() ?>
