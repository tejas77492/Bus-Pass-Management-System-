<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Bus Station</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background: #d9534f;
        }
        .navbar-brand, .nav-link {
            color: white !important;
        }
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
            color: white;
        }
        .sidebar a {
            padding: 10px;
            text-decoration: none;
            font-size: 18px;
            display: block;
            color: white;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background-color: #575d63;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #d9534f;
            font-weight: bold;
        }
        .facilities {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .facility-card {
            background: #ffebee;
            padding: 15px;
            border-radius: 8px;
            flex: 1;
            text-align: center;
            min-width: 200px;
        }
        .contact-info p {
            font-size: 18px;
            font-weight: 500;
        }
        .contact-info i {
            color: #d9534f;
            margin-right: 8px;
        }
        @media screen and (max-width: 768px) {
            .sidebar {
                width: 100px;
            }
            .content {
                margin-left: 110px;
            }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Bus Station</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                
            </div>
        </div>
    </nav>

    <!-- Sidebar
    <div class="sidebar">
        <a href="/"><i class="fas fa-home"></i> Home</a>
        <a href="users/create"><i class="fas fa-ticket-alt"></i> user</a>
        <a href="#"><i class="fas fa-phone"></i> Contact</a>
    </div> -->

    <!-- Main Content -->
    <div class="content">
        <div class="container mt-5">
            <h2 class="text-center">🚍 About Bus Station</h2>
            <p class="text-center">
                Our modern bus stations ensure seamless travel across major cities with comfortable facilities, 
                multiple bus routes, and excellent customer service.
            </p>

            <h4 class="mt-4">✨ Facilities:</h4>
            <div class="facilities">
                <div class="facility-card"><i class="fas fa-bus"></i> 24/7 Bus Service</div>
                <div class="facility-card"><i class="fas fa-ticket-alt"></i> Online Ticket Booking</div>
                <div class="facility-card"><i class="fas fa-chair"></i> Waiting Lounge & Restrooms</div>
                <div class="facility-card"><i class="fas fa-headset"></i> Help Desk & Customer Support</div>
            </div>

            <h4 class="mt-4">📞 Contact Information:</h4>
            <div class="contact-info">
                <p><i class="fas fa-map-marker-alt"></i> Location: Sangamner, Maharashtra</p>
                <p><i class="fas fa-phone"></i> Contact: 01234556789</p>
                <p><i class="fas fa-envelope"></i> Email: support@busstation.com</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
