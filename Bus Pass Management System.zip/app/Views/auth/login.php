<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/style.css"> <!-- Custom CSS -->
    <style>
        body {
            background: linear-gradient(135deg);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 350px;
        }
        .login-container h2 {
            color: #2575fc;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .form-control {
            border-radius: 20px;
            padding: 10px;
        }
        .btn-primary {
            border-radius: 20px;
            padding: 10px;
            width: 100%;
            font-weight: bold;
            background-color: #2575fc;
            border: none;
            transition: 0.3s;
        }
        .btn-primary:hover {
            background-color: #1a5db0;
        }
        .register-link {
            margin-top: 10px;
        }
        .register-link a {
            color: #2575fc;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>
    
    <?php if(session()->getFlashdata('error')): ?>
        <p class="text-danger"><?= session()->getFlashdata('error') ?></p>
    <?php endif; ?>

    <form action="/login" method="post">
        <div class="mb-3">
            <input type="text" name="username" class="form-control" placeholder="Username" required>
        </div>
        <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>

    <div class="register-link">
        <p>Don't have an account? <a href="/register">Register here</a></p>
    </div>
</div>

</body>
</html>
