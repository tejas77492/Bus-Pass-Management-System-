<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: url('/image/1.jpeg') no-repeat center center/cover;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .navbar {
            background: #d9534f !important;
        }.
        .navbar-brand {
            font-weight: bold;
        }
        .sidebar {
            width: 250px;
            position: fixed;
            height: 100%;
            background: #343a40;
            padding-top: 20px;
        }
        .sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .main-content {
            margin-left: 260px;
            padding: 20px;
        }
        .hero-section {
            height: 60vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 10px;
        }
        .hero-section h1 {
            font-size: 2.5rem;
            font-weight: bold;
        }
        .feature-card {
            padding: 20px;
            border-radius: 10px;
            color: white;
            margin-bottom: 15px;
            transition: transform 0.3s ease-in-out;
        }
        .feature-card:hover {
            transform: scale(1.05);
        }
        .bg-primary { background: #007bff; }
        .bg-success { background: #28a745; }
        .bg-warning { background: #ffc107; }
        .bg-danger { background: #dc3545; }
        .step-card {
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            font-weight: bold;
            transition: transform 0.3s;
        }
        .step-card:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">🚌 Bus Pass System</a>
        </div>
    </nav>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="/login"><i class="bi bi-person-fill"></i> Admin</a>
        <a href="/users/create"><i class="bi bi-person-plus-fill"></i> Users</a>
        <a href="/about"><i class="bi bi-info-circle-fill"></i> About us</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        
        <!-- Hero Section -->
        <div class="hero-section container my-4">
            <div>
                <h1>🚍 Welcome to Bus Pass Management System</h1>
                <p class="lead">Apply for your bus pass online with ease and convenience</p>
            </div>
        </div>

        <!-- Feature Section -->
        <div class="container py-5">
            <div class="row text-center">
                <div class="col-md-4">
                    <div class="feature-card bg-primary shadow">
                        <i class="bi bi-card-checklist" style="font-size: 3rem;"></i>
                        <h4 class="mt-3">Easy Pass Management</h4>
                        <p>Apply, renew, and track your bus pass online.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card bg-success shadow">
                        <i class="bi bi-lock" style="font-size: 3rem;"></i>
                        <h4 class="mt-3">Secure System</h4>
                        <p>Fully secure and encrypted database to protect your data.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card bg-warning shadow">
                        <i class="bi bi-cloud-download" style="font-size: 3rem;"></i>
                        <h4 class="mt-3">Online Application</h4>
                        <p>Apply for a pass anytime, anywhere.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Steps Section -->
        <div class="container py-5">
            <h2 class="text-center mb-4">🔹 How It Works</h2>
            <div class="row text-center">
                <div class="col-md-3">
                    <div class="step-card bg-info text-white shadow">
                        <h5>1️⃣ Register</h5>
                        <p>Sign up and create your account.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card bg-primary text-white shadow">
                        <h5>2️⃣ Apply</h5>
                        <p>Submit your bus pass application.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card bg-success text-white shadow">
                        <h5>3️⃣ Get Approved</h5>
                        <p>Admin verifies and approves your application.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="step-card bg-danger text-white shadow">
                        <h5>4️⃣ Download Pass</h5>
                        <p>Get your digital bus pass instantly.</p>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
