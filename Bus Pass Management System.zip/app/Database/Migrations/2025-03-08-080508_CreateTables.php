<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTables extends Migration
{
    public function up()
    {
        // Admin Table
        $this->forge->addField([
            'id' => [
                'type' => 'SERIAL',
                'unsigned' => true,
            ],
            'username' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
                'unique' => true,
            ],
            'password' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('admin');

        // Users Table
        $this->forge->addField([
            'id' => [
                'type' => 'SERIAL',
                'unsigned' => true,
            ],
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
                'unique' => true,
            ],
            'password' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'defaultExpression' => 'CURRENT_TIMESTAMP',
            ],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('users');

        // Bus Routes Table
        $this->forge->addField([
            'id' => [
                'type' => 'SERIAL',
                'unsigned' => true,
            ],
            'route_name' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
                'unique' => true,
            ],
            'cost' => [
                'type' => 'DECIMAL',
                'constraint' => '10,2',
                'null' => false,
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('bus_routes');

        // Bus Passes Table
        $this->forge->addField([
            'id' => [
                'type' => 'SERIAL',
                'unsigned' => true,
            ],
            'pass_id' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
                'unique' => true,
            ],
            'passenger_name' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'start_date' => [
                'type' => 'DATE',
            ],
            'end_date' => [
                'type' => 'DATE',
            ],
            'route_id' => [
                'type' => 'BIGINT',
                'unsigned' => true,
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addForeignKey('route_id', 'bus_routes', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('bus_passes');

        // Extends Passes Table
        $this->forge->addField([
            'id' => [
                'type' => 'SERIAL',
                'unsigned' => true,
            ],
            'pass_id' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
            ],
            'new_end_date' => [
                'type' => 'DATE',
                'null' => false,
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addForeignKey('pass_id', 'bus_passes', 'pass_id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('extends_passes');

        // Buses Table
        $this->forge->addField([
            'id' => [
                'type' => 'SERIAL',
                'unsigned' => true,
            ],
            'bus_number' => [
                'type' => 'VARCHAR',
                'constraint' => 20,
                'unique' => true,
            ],
            'bus_name' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'route_id' => [
                'type' => 'BIGINT',
                'unsigned' => true,
            ],
            'capacity' => [
                'type' => 'INT',
                'unsigned' => true,
            ],
            'status' => [
                'type' => 'VARCHAR',
                'constraint' => 10,
                'default' => 'Active',
            ],
            'created_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
            'updated_at' => [
                'type' => 'TIMESTAMP',
                'null' => false,
            ],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addForeignKey('route_id', 'bus_routes', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('buses');

        // Set default timestamps for PostgreSQL
        $db = \Config\Database::connect();
        $db->query("ALTER TABLE admin ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE users ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE bus_routes ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE bus_passes ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE bus_passes ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE extends_passes ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE extends_passes ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE buses ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP;");
        $db->query("ALTER TABLE buses ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP;");
    }

    public function down()
    {
        $this->forge->dropTable('buses', true);
        $this->forge->dropTable('extends_passes', true);
        $this->forge->dropTable('bus_passes', true);
        $this->forge->dropTable('bus_routes', true);
        $this->forge->dropTable('users', true);
        $this->forge->dropTable('admin', true);
    }
}
